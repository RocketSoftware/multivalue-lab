﻿using System;

namespace $safeprojectname$
{
    /// <summary>
    /// This is the code behind for the theme that SB/XA will use. In order to register it with SB/XA you need to upload the assemblies created by this 
    /// project using the process in SB/XA /ASD. Once the assembly has been uploaded /THEME.DEFN  can be used to define the theme to SB/XA the class name 
    /// will be the fully qualified name of this class.
    /// </summary>
    partial class CustomTheme
    {
        public CustomTheme()
        {
            try
            {
                InitializeComponent();
            }
            catch (Exception)
            {
                ;
            }
        }


    }
}
